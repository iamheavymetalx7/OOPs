name = "Jim" # str
print(len(name))

some_list = ["some","name"] # list
print(len(some_list))
# That's polymorphism in action, a single function does now
# how to handle different kinds of objects as expected!