# 01 - Introduction

## This is the First Episode for the OOP Course

### main.py file includes the code we have written till the end of the episode